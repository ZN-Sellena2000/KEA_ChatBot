import "./App.css";
import Garage from "./Garage";

function App() {
  return (
    <div>
      <Garage />
    </div>
  );
}

export default App;
